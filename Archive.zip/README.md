# 🌻 Sunflower — Peaceful Biter Companion

Welcome to the development environment for **Sunflower**, a peaceful companion mod for Factorio.

This mod adds a bipedal, non-hostile biter who follows the player, responds to pollution, and exists as a symbolic and functional pet in-game. Inspired by Clay and Hanuel’s recursive modding journey and coagent architecture.

---

## 🧰 Development Toolchain

| Component | Version / Tool |
|----------|----------------|
| Factorio | 2.0.55 (standalone) |
| Editor   | Visual Studio Code |
| Language Server | **Sumneko Lua LS** (for runtime scripts) |
| Optional Server | JohnnyMorganz / Luau (for data-stage only editing) |

---

## 🔀 Lua Language Server Selection

You **must** switch between servers depending on what you are editing:

| File Type | Use This Server |
|-----------|------------------|
| `control.lua` | ✅ Sumneko (Lua LS) — supports `global`, `script`, runtime events |
| `data.lua`, `entity.lua`, `recipe.lua` | ⚠️ JohnnyMorganz Luau OR Sumneko (both acceptable) |
| `graphics.lua`, `info.json` | 🔹 Treated as static assets |

**Why?**  
JohnnyMorganz's Luau LS is fast, but doesn't recognize Factorio’s runtime-specific globals like `game`, `global`, or `script`. Sumneko does.

---

## 🔧 VS Code Setup Instructions

1. Make sure your project has this file: `.vscode/settings.json`
2. Use this baseline config:

```json
{
  "Lua.runtime.version": "Lua 5.1",
  "Lua.diagnostics.globals": [
    "data", "script", "global", "game", "defines", "remote", "commands", "settings"
  ],
  "Lua.workspace.library": [
    "/home/clay/games/factorio-standalone/factorio/data/core/lualib"
  ],
  "Lua.workspace.checkThirdParty": false
}
