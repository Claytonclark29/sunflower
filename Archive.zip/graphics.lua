-- graphics.lua

local graphics = {
  walk = {
    filename = "__sunflower_biter__/graphics/sunflower_walk.png",
    width = 64,
    height = 64,
    frame_count = 4,
    line_length = 4,
    direction_count = 2,
    animation_speed = 0.3,
    shift = {0, 0},
    scale = 0.5
  },
  
  blink = {
    filename = "__sunflower_biter__/graphics/sunflower_blink.png",
    width = 64,
    height = 64,
    frame_count = 3,
    line_length = 3,
    direction_count = 2,
    animation_speed = 0.2,
    shift = {0, 0},
    scale = 0.5
  }
}

return graphics