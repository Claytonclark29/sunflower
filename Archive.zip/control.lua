-- control.lua — Sunflower Biter Companion (runtime logic)

-- Called when a new world is created or mod is added.
script.on_init(function()
  global.sunflowers = {}
end)

-- Called when the mod is reloaded from a save (not needed here, but included for future state).
script.on_load(function()
  -- Nothing to rebind for now
end)

-- When a sunflower-biter is built/placed in the world.
script.on_event(defines.events.on_built_entity, function(event)
  local entity = event.created_entity or event.entity
  if entity and entity.valid and entity.name == "sunflower-biter" then
    if not global.sunflowers then global.sunflowers = {} end
    table.insert(global.sunflowers, entity)
  end
end)

-- When a sunflower-biter is destroyed (e.g. mined, killed).
script.on_event(defines.events.on_entity_died, function(event)
  if event.entity and event.entity.valid and event.entity.name == "sunflower-biter" then
    for i, e in ipairs(global.sunflowers or {}) do
      if e == event.entity then
        table.remove(global.sunflowers, i)
        break
      end
    end
  end
end)

-- Main tick logic, runs every 60 ticks (~1 second).
script.on_nth_tick(60, function()
  if not global.sunflowers then return end

  for i = #global.sunflowers, 1, -1 do
    local sunflower = global.sunflowers[i]
    if not sunflower.valid then
      table.remove(global.sunflowers, i)
    else
      local surface = sunflower.surface
      local pollution = surface.get_pollution(sunflower.position)

      -- Recolor based on pollution level
      if pollution > 20 then
        sunflower.color = {r = 0.4, g = 0.4, b = 1.0, a = 0.9} -- blue-tinted
      else
        sunflower.color = {r = 1.0, g = 1.0, b = 1.0, a = 1.0} -- default
      end

      -- Find nearest player to follow
local nearest = surface.find_nearest_entity{
  position = sunflower.position,
  radius = 24,
  force = "player",
  type = "player"
}

      if nearest then
        sunflower.set_command{
          type = defines.command.go_to_location,
          destination = nearest.position,
          distraction = defines.distraction.none
        }
      end
    end
  end
end)