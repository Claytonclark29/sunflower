-- item.lua

data:extend({
  {
    type = "item",
    name = "sunflower-biter",
    icon = "__sunflower_biter__/graphics/sunflower-icon.png",
    icon_size = 64,
    subgroup = "capsule",
    order = "z[sunflower]",
    stack_size = 1,
    place_result = "sunflower-biter"
  }
})