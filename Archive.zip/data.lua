-- data.lua

-- Graphics must be loaded first so the entity can use them.
require("graphics")

require("entity")
require("item")
require("recipe")