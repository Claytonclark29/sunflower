-- entity.lua (Final Stable Blueprint)

data:extend({
  {
    type = "unit",
    name = "sunflower-biter",
    icon = "__sunflower_biter__/graphics/sunflower-icon.png",
    icon_size = 64,
    flags = {"placeable-player", "placeable-neutral", "not-on-map"},
    force = "player",
    max_health = 15,
    subgroup = "creatures",
    order = "a-b-a",
    resistances = { { type = "physical", decrease = 0, percent = 0 } },
    spawning_time_modifier = 2,
    collision_box = {{-0.3, -0.3}, {0.3, 0.3}},
    selection_box = {{-0.4, -0.4}, {0.4, 0.4}},
    sticker_box = {{-0.6, -0.7}, {0.6, 0.2}},
    distraction_cooldown = 300,
    max_pursue_distance = 10,
    vision_distance = 30,
    movement_speed = 0.14,
    distance_per_frame = 0.1,
    absorptions_to_join_attack = { pollution = 999999 },
    run_animation = { layers = { { filename = "__sunflower_biter__/graphics/sunflower-icon.png", priority = "extra-high", width = 64, height = 64, frame_count = 1, direction_count = 1, scale = 0.5 } } },
    corpse = "small-biter-corpse",
    attack_parameters = {
      type = "projectile",
      range = 0,
      cooldown = 99999,
      animation = { layers = { { filename = "__sunflower_biter__/graphics/sunflower-icon.png", width = 64, height = 64, frame_count = 1, scale = 0.5 } } },
      ammo_category = "biological",
      ammo_type = { category = "biological", action = { type = "direct", action_delivery = { type = "instant", target_effects = { type = "damage", damage = { type = "physical", amount = 0 } } } } }
    },
    animations = {
      idle = {
        layers = {
          { animation = { filename = "__sunflower_biter__/graphics/sunflower_walk.png", width = 64, height = 64, frame_count = 4, line_length = 4, direction_count = 2}, run_mode = "forward-then-backward", animation_speed = 0.25 },
          { probability = 1 / (60 * 5), animation = { filename = "__sunflower_biter__/graphics/sunflower_blink.png", width = 64, height = 64, frame_count = 3, line_length = 3, direction_count = 2} }
        }
      }
    }
  }
})