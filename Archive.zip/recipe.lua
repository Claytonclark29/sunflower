data:extend({
  {
    type = "recipe",
    name = "sunflower-biter",
    enabled = true,
    ingredients = {
      {type = "item", name = "wood", amount = 5},
      {type = "item", name = "electronic-circuit", amount = 2}
    },
    results = {
      {
        type = "item",
        name = "sunflower-biter",
        amount = 1
      }
    }
  }
})